<?php

use yii\db\Migration;

class m160917_123213_create_index_subject_title extends Migration
{
    public function up()
    {
        //$this->createIndex('idx-subject-title', '{{%subject}}', ['title']);
    }

    public function down()
    {
        //$this->dropIndex('idx-subject-title', '{{%subject}}');
    }
}
